-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Pschedule`
--

DROP TABLE IF EXISTS `Pschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pschedule` (
  `contractId` int(11) NOT NULL AUTO_INCREMENT,
  `events` varchar(100) DEFAULT NULL,
  `schedule` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`contractId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pschedule`
--

LOCK TABLES `Pschedule` WRITE;
/*!40000 ALTER TABLE `Pschedule` DISABLE KEYS */;
INSERT INTO `Pschedule` VALUES (1,'Wedding','Monday'),(2,'Sweet 16','Tuesday'),(3,'Batism','Wednesday'),(4,'Aniversary','Thursday'),(5,'Wedding','Friday'),(6,'Sweet 16','Saturday'),(7,'Batism','Sunday'),(8,'Aniversary','Monday'),(9,'Wedding','Tuesday'),(10,'Sweet 16','Wednesday');
/*!40000 ALTER TABLE `Pschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `contractId` int(11) NOT NULL,
  `customerId` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `payments` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`contractId`),
  KEY `customerId` (`customerId`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `inquiryForm` (`customerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,NULL,'VIP',500.00),(2,NULL,'Platinum Member',249.99),(3,NULL,'VIP',800.89),(4,NULL,'Regular Customer',300.23),(5,NULL,'VIP',50.78),(6,NULL,'Regular Customer',123.67),(7,NULL,'Platinum Member',345.00),(8,NULL,'Regular Member',452.88),(9,NULL,'Platinum Member',678.88),(10,NULL,'Regular Member',500.00);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `contractId` int(11) NOT NULL AUTO_INCREMENT,
  `pName` varchar(30) DEFAULT NULL,
  `firstName` varchar(25) DEFAULT NULL,
  `lastName` varchar(25) DEFAULT NULL,
  `service` varchar(30) DEFAULT NULL,
  `package` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`contractId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'Rose','Gray','Lora','Wedding','Premium'),(2,'Luisa','Navarro','Nora','Sweet 16','Gold'),(3,'Barry','Alen','Harrison','Aniversary','Silver'),(4,'Rose','Gonzales','Cisco','Batism','Premium'),(5,'Luisa','Spibot','Lisa','Wedding','Gold'),(6,'Barry','Feinberg','Michell','Sweet 16','Silver'),(7,'Rose','Stone','Castellanos','Aniversary','Premium'),(8,'Luisa','Morales','Patty','Batism','Gold'),(9,'Barry','West','Guideon','Photoshoot','Silver'),(10,'Rose','Wells','Palmer','Photoshoot','Premium');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataEntry`
--

DROP TABLE IF EXISTS `dataEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dataEntry` (
  `packageId` int(11) NOT NULL,
  `photographerId` int(11) DEFAULT NULL,
  `details` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`packageId`),
  KEY `photographerId` (`photographerId`),
  CONSTRAINT `dataentry_ibfk_1` FOREIGN KEY (`photographerId`) REFERENCES `photographer` (`photographerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataEntry`
--

LOCK TABLES `dataEntry` WRITE;
/*!40000 ALTER TABLE `dataEntry` DISABLE KEYS */;
INSERT INTO `dataEntry` VALUES (1,NULL,'2 photos 10 x 20, 4 photos 20 x 24'),(2,NULL,'1 photo 2 x 2, 3 photos 8 x 10'),(3,NULL,'5 photos 16 x 20, 3 photos 11 x 14'),(4,NULL,'2 photos 10 x 20, 4 photos 20 x 24'),(5,NULL,'1 photo 2 x 2, 3 photos 8 x 10'),(6,NULL,'5 photos 16 x 20, 3 photos 11 x 14'),(7,NULL,'2 photos 10 x 20, 4 photos 20 x 24'),(8,NULL,'1 photo 2 x 2, 3 photos 8 x 10'),(9,NULL,'5 photos 16 x 20, 3 photos 11 x 14'),(10,NULL,'R1 photo 2 x 2, 3 photos 8 x 10');
/*!40000 ALTER TABLE `dataEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiryForm`
--

DROP TABLE IF EXISTS `inquiryForm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiryForm` (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(25) DEFAULT NULL,
  `lastName` varchar(25) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `phoneNumber` varchar(15) DEFAULT NULL,
  `package` varchar(20) DEFAULT NULL,
  `service` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`customerId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiryForm`
--

LOCK TABLES `inquiryForm` WRITE;
/*!40000 ALTER TABLE `inquiryForm` DISABLE KEYS */;
INSERT INTO `inquiryForm` VALUES (1,'Rose','Gray','123 west','123-456-7689','Premium','Wedding'),(2,'Luisa','Navarro','5346 Broadway','555-444-7689','Gold','Sweet 16'),(3,'Barry','Alen','Church Street','123-222-0909','Silver','Aniversary'),(4,'Sara','Gonzales','Star City','123-346-7689','Premium','Batism'),(5,'Liz','Spibot','1234 Amsterdam','123-456-6754','Gold','Wedding'),(6,'Barry','Feinberg','Star City','777-456-7689','Silver','Sweet 16'),(7,'Patty','Stone','Church Street','123-543-8765','Premium','Aniversary'),(8,'Joe','Morales','Central City','222-786-7689','Gold','Batism'),(9,'Iris','West','123 west','333-456-7689','Silver','Photoshoot'),(10,'Ramon','Wells','Central City','333-888-7689','Premium','Photoshoot');
/*!40000 ALTER TABLE `inquiryForm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `packageId` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) DEFAULT NULL,
  `price` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`packageId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (11,'4 cam, ceremony coverage,',350.89),(12,'3 cam, post-cereemony coverage',100.65),(13,'1 cam, Single camera editing',50.99),(14,'4 cam, ceremony coverage',350.89),(15,'3 cam, post-cereemony coverage',100.65),(16,'1 cam, Single camera editing',50.99),(17,'4 cam, ceremony coverage',350.89),(18,'3 cam, post-cereemony coverage',100.65),(19,'1 cam, Single camera editing',50.99),(20,'4 cam, ceremony coverage',350.89);
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photographer`
--

DROP TABLE IF EXISTS `photographer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photographer` (
  `photographerId` int(11) NOT NULL AUTO_INCREMENT,
  `pSchedule` varchar(50) DEFAULT NULL,
  `pName` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`photographerId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photographer`
--

LOCK TABLES `photographer` WRITE;
/*!40000 ALTER TABLE `photographer` DISABLE KEYS */;
INSERT INTO `photographer` VALUES (1,'Rose','Mon-Tues-Fri'),(2,'Luisa','Wed-Thur-Sat'),(3,'Barry','Sun-Mon-Wed'),(4,'Rose','Mon-Tues-Fri'),(5,'Luisa','Sun-Mon-Wed'),(6,'Barry','Mon-Tues-Fri'),(7,'Rose','Sun-Mon-Wed'),(8,'Luisa','Wed-Thur-Sat'),(9,'Barry','Wed-Thur-Sat'),(10,'Rose','Wed-Thur-Sat');
/*!40000 ALTER TABLE `photographer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekly`
--

DROP TABLE IF EXISTS `weekly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekly` (
  `photographerId` int(11) NOT NULL,
  `pName` varchar(30) DEFAULT NULL,
  `activities` varchar(50) DEFAULT NULL,
  `workingDay` date DEFAULT NULL,
  PRIMARY KEY (`photographerId`),
  CONSTRAINT `weekly_ibfk_1` FOREIGN KEY (`photographerId`) REFERENCES `photographer` (`photographerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly`
--

LOCK TABLES `weekly` WRITE;
/*!40000 ALTER TABLE `weekly` DISABLE KEYS */;
INSERT INTO `weekly` VALUES (1,'Rose','wedding','2019-12-20'),(2,'Luisa','Sweet 16','2019-12-20'),(3,'Barry','Batism','2019-12-20'),(4,'Rose','Aniversary','2019-12-20'),(5,'Luisa','wedding','2019-12-20'),(6,'Barry','sweet 16','2019-12-20'),(7,'Rose','batism','2019-12-20'),(8,'Luisa','aniversary','2019-12-20'),(9,'Barry','wedding','2019-12-20'),(10,'Rose','batism','2019-12-20');
/*!40000 ALTER TABLE `weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'project'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-20 21:16:53
